<template>
  <div id="app">
    <!-- 路由的出口 -->
    <router-view />
  </div>
</template>
<script>
export default {
  name: 'App' // 建议给组件都取一个名
}
</script>
<style lang="less">

</style>
