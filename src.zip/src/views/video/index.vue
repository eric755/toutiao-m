<template>
  <div class="video-container">
    <h1>视频</h1>
  </div>
</template>

<script>
export default {
  name: 'VideoIndex',
  components: {},
  props: {},
  data () {
    return {}
  },
  computed: {},
  watch: {},
  created () {},
  mounted () {},
  methods: {}
}
</script>

<style scoped lang="less">
</style>
