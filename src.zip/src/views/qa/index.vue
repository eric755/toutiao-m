<template>
  <div class="qa-container">
    <h1>问答</h1>
  </div>
</template>

<script>
export default {
  name: 'QaIndex',
  components: {},
  props: {},
  data () {
    return {}
  },
  computed: {},
  watch: {},
  created () {},
  mounted () {},
  methods: {}
}
</script>

<style scoped lang="less">
</style>
